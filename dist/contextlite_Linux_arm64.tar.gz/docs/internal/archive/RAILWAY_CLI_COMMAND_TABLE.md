# Railway CLI Command Reference Table

## ❌ COMMANDS THAT WILL LOCK UP (INTERACTIVE) - NEVER USE WITHOUT FLAGS

| Command | Why It Locks Up | Safe Alternative |
|---------|----------------|------------------|
| `railway service` | Opens interactive service selector | `railway service <SERVICE_NAME>` |
| `railway environment` | Opens interactive environment selector | `railway environment <ENV_NAME>` |
| `railway link` | Opens interactive project/team selector | `railway link -p <PROJECT> -s <SERVICE>` |
| `railway up` | Can prompt for service selection | `railway up -s <SERVICE>` |
| `railway redeploy` | Can prompt for confirmation | `railway redeploy -s <SERVICE> -y` |
| `railway down` | Prompts for confirmation | `railway down -y` |
| `railway ssh` | Prompts for service selection | `railway ssh -s <SERVICE>` |
| `railway logs` | Can prompt for service selection | `railway logs -s <SERVICE>` |
| `railway variables` | Can prompt for service selection | `railway variables -s <SERVICE>` |
| `railway connect` | Prompts for database selection | `railway connect <SERVICE_NAME>` |

## ✅ SAFE NON-INTERACTIVE COMMANDS 

| Command | Description | Required Flags | Example |
|---------|-------------|----------------|---------|
| `railway up -s <SERVICE>` | Deploy to specific service | `-s <SERVICE>` | `railway up -s contextlite-testing` |
| `railway redeploy -s <SERVICE> -y` | Redeploy without confirmation | `-s <SERVICE> -y` | `railway redeploy -s contextlite-testing -y` |
| `railway service <SERVICE>` | Link to specific service | Service name as argument | `railway service contextlite-testing` |
| `railway environment <ENV>` | Link to specific environment | Environment name as argument | `railway environment production` |
| `railway status` | Show current status | None | `railway status` |
| `railway list` | List all projects | None | `railway list` |
| `railway whoami` | Show current user | None | `railway whoami` |
| `railway login` | Login to Railway | None | `railway login` |
| `railway logout` | Logout from Railway | None | `railway logout` |
| `railway variables -s <SERVICE>` | Show variables for service | `-s <SERVICE>` | `railway variables -s contextlite-testing` |
| `railway logs -s <SERVICE>` | Show logs for service | `-s <SERVICE>` | `railway logs -s contextlite-testing` |
| `railway ssh -s <SERVICE> -- <CMD>` | Execute command via SSH | `-s <SERVICE> --` | `railway ssh -s contextlite-testing -- ls -la` |
| `railway connect <SERVICE>` | Connect to database | Service name as argument | `railway connect postgres` |
| `railway domain -s <SERVICE>` | Generate domain for service | `-s <SERVICE>` | `railway domain -s contextlite-testing` |
| `railway down -y` | Remove deployment without confirmation | `-y` | `railway down -y` |

## 🔑 AUTHENTICATION METHODS

| Method | Token Type | Commands That Work | Commands That DON'T Work |
|--------|------------|-------------------|------------------------|
| `RAILWAY_TOKEN` (Project Token) | Project-scoped | `up`, `redeploy`, `status`, `variables`, `ssh` | `whoami`, `list`, `logs` (sometimes) |
| `railway login` (Account Token) | User account | ALL commands | None |

## 📋 DEPLOYMENT WORKFLOW (CORRECT USAGE)

1. **Set Authentication**: `export RAILWAY_TOKEN="your-token"`
2. **Deploy**: `railway up -s contextlite-testing`
3. **Check Status**: `railway status`
4. **View Logs**: `railway logs -s contextlite-testing` 
5. **Redeploy**: `railway redeploy -s contextlite-testing -y`

## 🚨 CRITICAL RULES

1. **ALWAYS specify service with `-s <SERVICE>`** for deployment commands
2. **ALWAYS use `-y` flag** for confirmation-requiring commands
3. **NEVER use bare commands** that can trigger interactive prompts
4. **Use `--` before SSH commands** to separate flags from the command
5. **Project tokens have limited permissions** - use account login for full access

## 🎯 OUR SPECIFIC SERVICES

- `contextlite-testing` - Testing service with abandoned cart system (has SQL bug)
- `contextlite` - Main production service (no abandoned cart endpoints)
- `contextlite-backup` - Backup service (no abandoned cart endpoints)

## 💥 CURRENT ISSUE & SOLUTION

**Problem**: SQL bug in `contextlite-testing` service
**Fix Applied**: Added `COALESCE()` to handle NULL values in SQL query
**Deployment**: `railway redeploy -s contextlite-testing -y`
