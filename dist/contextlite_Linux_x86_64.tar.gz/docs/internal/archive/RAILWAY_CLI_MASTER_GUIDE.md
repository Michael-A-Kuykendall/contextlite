# Railway CLI Master Guide - Complete Reference

## 🚨 CRITICAL UNDERSTANDING: Interactive vs Non-Interactive Commands

**THE ROOT PROBLEM**: Railway CLI commands default to interactive prompts that LOCK UP automated scripts.

### ✅ CORRECT: Non-Interactive Commands
```bash
# ALWAYS specify service/environment explicitly
railway service contextlite-testing
railway logs -s contextlite-testing  
railway up -s contextlite-testing
railway variables -s contextlite-testing
railway ssh -s contextlite-testing -- ls

# Link with specific parameters (no prompts)
railway link -s contextlite-testing -e production
```

### ❌ WRONG: Interactive Commands (WILL LOCK UP)
```bash
# These open interactive selectors - NEVER USE IN SCRIPTS
railway service      # Opens selector menu
railway ssh          # Waits for service selection
railway environment  # Opens environment selector
railway link         # Opens project/service selector
```

## 🔑 Authentication Methods

### Project Tokens (What We Use)
```bash
export RAILWAY_TOKEN="d66cb512-df83-4f65-8bfb-77074517baaa"

# Project tokens can do:
railway up           # Deploy to project
railway logs         # View logs (MAY BE RESTRICTED)
railway status       # Check project status
railway redeploy     # Redeploy service
railway variables    # View/set environment variables

# Project tokens CANNOT do:
railway whoami       # User info (requires account token)
railway init         # Create new projects
railway list         # List all projects
```

### Account Tokens (For User Operations)
```bash
export RAILWAY_API_TOKEN="your-account-token"

# Account tokens can do everything:
railway whoami       # User information
railway list         # List all projects
railway init         # Create projects
railway link         # Link to projects
```

### Priority Rules
- If both `RAILWAY_TOKEN` and `RAILWAY_API_TOKEN` are set, `RAILWAY_TOKEN` takes precedence
- Use ONLY ONE type of token at a time

## 📋 Current Project Structure (Mike's Setup)

### Project: carefree-wonder
```json
{
  "project_id": "0f26b2c3-f9ad-4e9e-9470-786a36aefd55",
  "environment": "production",
  "services": [
    {
      "name": "contextlite-testing",
      "id": "41ac10c7-f286-4c42-87e2-99e8474c80f1",
      "domain": "contextlite-testing-production.up.railway.app",
      "status": "Has abandoned cart system with SQL bug"
    },
    {
      "name": "contextlite", 
      "id": "53b2e1d8-ead2-4d15-9e90-3ed4343b4ab4",
      "domain": "contextlite-production.up.railway.app",
      "status": "Main production service, no abandoned cart endpoints"
    },
    {
      "name": "contextlite-backup",
      "id": "8f412aef-d688-4c0b-bb16-8900d3e51c95", 
      "domain": "contextlite-backup-production.up.railway.app",
      "status": "Backup service, no abandoned cart endpoints"
    }
  ]
}
```

## 🎯 Service Management Commands

### Switch Services
```bash
# Switch to specific service
railway service contextlite-testing
railway service contextlite
railway service contextlite-backup

# Check current status
railway status
railway status --json  # Structured output
```

### Deploy Commands
```bash
# Deploy to specific service
railway up -s contextlite-testing
railway up -s contextlite --detach    # Deploy and return immediately
railway up -s contextlite-backup

# Redeploy existing deployment
railway redeploy -s contextlite-testing -y  # Skip confirmation
```

### Log Management
```bash
# View logs (REQUIRES ACCOUNT TOKEN - may fail with project token)
railway logs -s contextlite-testing
railway logs -s contextlite -b          # Build logs only
railway logs -s contextlite -d          # Deployment logs only
```

### Variable Management
```bash
# View environment variables
railway variables -s contextlite-testing
railway variables -s contextlite --json
railway variables -s contextlite --kv   # Key-value format

# Set variables
railway variables -s contextlite --set "KEY=value"
railway variables -s contextlite --set "DEBUG=true" --set "PORT=8080"
```

## 🖥️ SSH and Remote Commands

### Non-Interactive SSH (CORRECT WAY)
```bash
# Execute single commands (no interactive session)
railway ssh -s contextlite-testing -- ls -la
railway ssh -s contextlite-testing -- cat /app/abandoned_carts.db
railway ssh -s contextlite-testing -- ps aux
railway ssh -s contextlite-testing -- find /app -name "*.db"

# Check if database files exist
railway ssh -s contextlite-testing -- ls -la /app/*.db
railway ssh -s contextlite-testing -- du -h /app/abandoned_carts.db
```

### SSH Limitations
- Some containers don't have shell (`sh` not found in `$PATH`)
- No SCP/SFTP support
- No port forwarding
- Uses websockets, not SSH protocol

## 🔍 Debugging and Monitoring

### Health Checks
```bash
# Check service health via HTTP
curl -s "https://contextlite-testing-production.up.railway.app/health"
curl -s "https://contextlite-production.up.railway.app/health"
curl -s "https://contextlite-backup-production.up.railway.app/health"
```

### Abandoned Cart Investigation
```bash
# Current endpoints that work:
curl -s "https://contextlite-testing-production.up.railway.app/cart/status"
curl -X POST "https://contextlite-testing-production.up.railway.app/cart/abandon"

# Endpoints that return 404:
curl -s "https://contextlite-production.up.railway.app/cart/status"
curl -s "https://contextlite-backup-production.up.railway.app/cart/status"
```

### Service Status Check
```bash
# Get detailed service information
railway status --json | jq '.services.edges[].node | {name: .name, id: .id}'

# Check deployment status
railway status --json | jq '.services.edges[].node.serviceInstances.edges[].node.latestDeployment.status'
```

## 🛠️ Advanced Operations

### Project Linking
```bash
# Link to specific project/service (no interactive prompts)
railway link -p "0f26b2c3-f9ad-4e9e-9470-786a36aefd55" -e production -s contextlite-testing

# Unlink current directory
railway unlink
railway unlink -s  # Unlink service only
```

### Environment Management
```bash
# Switch environments (avoid interactive)
railway environment production  # If you know the name
railway environment --json      # List environments
```

### Domain Management  
```bash
# Generate domain for service
railway domain -s contextlite-testing
railway domain -s contextlite-testing -p 8080  # Specify port

# Add custom domain
railway domain custom.example.com -s contextlite-testing
```

## 🚨 TROUBLESHOOTING COMMON ISSUES

### "Unauthorized" Errors
```bash
# Check which token is active
echo $RAILWAY_TOKEN
echo $RAILWAY_API_TOKEN

# Use correct token for operation:
# Project operations: RAILWAY_TOKEN
# User operations: RAILWAY_API_TOKEN
```

### "Must provide project when setting service" Error
```bash
# Wrong way:
railway ssh -s contextlite-testing

# Correct way:
railway service contextlite-testing
railway ssh

# Or use full specification:
railway ssh -p "0f26b2c3-f9ad-4e9e-9470-786a36aefd55" -s contextlite-testing
```

### Interactive Command Lockups
```bash
# If command locks up waiting for input:
# 1. Cancel with Ctrl+C
# 2. Use non-interactive version with explicit parameters
# 3. Never use bare commands like `railway service` in scripts
```

### SSH "No shell found" Error
```bash
# Container has no shell - use HTTP endpoints instead
curl -s "https://service-domain.railway.app/endpoint"

# Or check if specific commands exist
railway ssh -s service-name -- which ls
railway ssh -s service-name -- echo "test"
```

## 📊 CURRENT ABANDONED CART STATUS

### Testing Service (Has Abandoned Cart System)
- **URL**: `https://contextlite-testing-production.up.railway.app`
- **Status**: Abandoned cart system deployed but has SQL bug
- **Error**: `"sql: Scan error on column index 3, name "total_value": converting NULL to int64 is unsupported"`
- **Endpoints Working**: `/cart/abandon` (POST), `/health` (GET)
- **Endpoints Broken**: `/cart/status` (GET) - SQL error

### Main Service (No Abandoned Cart System)
- **URL**: `https://contextlite-production.up.railway.app`  
- **Status**: Healthy license server, no abandoned cart endpoints
- **Endpoints Working**: `/health` (GET)
- **Endpoints Missing**: All `/cart/*` endpoints return 404

### Backup Service (No Abandoned Cart System)
- **URL**: `https://contextlite-backup-production.up.railway.app`
- **Status**: Healthy license server, no abandoned cart endpoints  
- **Endpoints Working**: `/health` (GET)
- **Endpoints Missing**: All `/cart/*` endpoints return 404

## 🎯 IMMEDIATE ACTIONS NEEDED

1. **Fix SQL Bug in Testing Service**:
   - The SQL query has NULL handling issue in `total_value` column
   - Database has abandoned cart records (causing the NULL error)
   - Fix the SQL query to handle NULL values properly

2. **Deploy Abandoned Cart System to Main Services**:
   - Deploy updated code to `contextlite` (main production)
   - Deploy updated code to `contextlite-backup`
   - Ensure proper database initialization

3. **Get Real Abandoned Cart Count**:
   - Fix the SQL bug first
   - Then call `/cart/status` endpoint for accurate count
   - Alternative: SSH into testing service and query database directly

## 💡 RAILWAY CLI BEST PRACTICES

1. **Always Use Non-Interactive Mode**:
   - Specify `-s service-name` for service operations
   - Use `--json` for structured output
   - Include `-y` to skip confirmations

2. **Token Management**:
   - Use project tokens for deployment/monitoring
   - Use account tokens for user operations
   - Never mix both token types

3. **Error Handling**:
   - Check exit codes: `echo $?`
   - Use `--json` output for parsing
   - Test commands manually before scripting

4. **SSH Alternatives**:
   - Prefer HTTP endpoints over SSH when possible
   - Use single-command SSH execution
   - Check container capabilities first

---

**Updated**: August 28, 2025
**Status**: Production Ready - Use This Guide
**Next**: Fix SQL bug in abandoned cart system, deploy to all services
